package edu.uwi.cavehill.bus_pass_phone;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    private Handler mHandler;
    private Runnable mRunnable;

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_LANGUAGE = "languageKey";
    private static final String KEY_SHARED_PREFERENCES_DARK_MODE = "darkModeKey";
    private static final String KEY_SHARED_PREFERENCES_LOCKED_SCREEN = "lockedScreenKey";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        //needed for shared preferences class
        edu.uwi.cavehill.bus_pass_phone.DefaultSharedPreferences.instance(this.getApplicationContext());

        loadSplashTheme();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        splashDelay();

        }

    private void splashDelay() {

        mRunnable = new Runnable() {
            @Override
            public void run() {

                //has to be placed here to work
                loadLocal();
                lockScreen();
                }
            };

        mHandler = new Handler();
        mHandler.postDelayed(mRunnable, 3000);
        }

    protected void onDestroy() {

        super.onDestroy();
        if (mHandler != null && mRunnable != null) {
            mHandler.removeCallbacks(mRunnable);
            }
        }

    private void loadSplashTheme(){

        boolean darkMode = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_DARK_MODE);
        if (darkMode){ setTheme(R.style.DarkSplashTheme); }
        }

    //could only get the language in prefs to load here
    private void setLocale(String language) {

        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getBaseContext().getResources().updateConfiguration(configuration,
                getBaseContext().getResources().getDisplayMetrics());
        DefaultSharedPreferences.instance().storeValueString(KEY_SHARED_PREFERENCES_LANGUAGE, language);
        }

    public void loadLocal(){

        String language = DefaultSharedPreferences.instance().fetchValueString(KEY_SHARED_PREFERENCES_LANGUAGE);
        setLocale(language);
        }

    public void lockScreen(){

        boolean lockedScreen = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_LOCKED_SCREEN);
        if(lockedScreen){
            Intent intent = new Intent(this, PhoneAuthentication.class);
            startActivity(intent);
            finish();

        } else {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
            }
        }
    }