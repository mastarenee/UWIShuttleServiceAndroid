package edu.uwi.cavehill.bus_pass_phone;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Objects;
import es.dmoral.toasty.Toasty;

public class ShuttleCardFragment extends Fragment {

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_QR_CODE = "textQRCodeKey";
    private static final String KEY_SHARED_PREFERENCES_USER_NAME = "userNameKey";
    private static final String KEY_SHARED_PREFERENCES_USER_LOGGED = "userLoggedKey";
    private static final String KEY_SHARED_PREFERENCES_IMAGE_QR_CODE = "imageQRCodeKey";

    ImageView QRcodeImage;

    View view;

    private Toolbar shuttleCardToolbar;
    private TextView shuttleCarduserName;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.frament_shuttle_card, container, false);

        shuttleCardToolbar = view.findViewById(R.id.shuttle_card_toolbar);
        shuttleCardToolbar.setTitle(R.string.toolBar_shuttle_card);
        shuttleCarduserName = view.findViewById(R.id.shuttle_card_text);
        QRcodeImage = view.findViewById(R.id.shuttle_card_image);

        setUpQRCode();

        return view;
    }

    private void setUpQRCode(){

        String QRCodeImageName = "defaultQRCode";

        //shared preferences display user name
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String prefUserName = sharedPreferences.getString(KEY_SHARED_PREFERENCES_USER_NAME, "defaultValue");
        String prefQRCodeText = sharedPreferences.getString(KEY_SHARED_PREFERENCES_QR_CODE, "defaultValue");
        SharedPreferences.Editor editor = sharedPreferences.edit();
        shuttleCarduserName.setText(prefUserName);

        //shared preferences display user name
        boolean prefGetQRBool = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_IMAGE_QR_CODE, false);
        if (prefGetQRBool){
            try{

                QRcodeImage.setImageBitmap(loadImageLocal(QRCodeImageName));
                }catch (IllegalArgumentException ignored){}

            }else{

            if(!prefQRCodeText.equals("defaultValue")){

                try{

                    Bitmap newQRCode;
                    newQRCode = createQRcode(prefQRCodeText);
                    QRcodeImage.setImageBitmap(newQRCode);
                    saveImageLocal(newQRCode, QRCodeImageName);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_IMAGE_QR_CODE, true);
                    editor.apply();

                    //custom toast
                    Toast toast = Toasty.success(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_logged_in), Toast.LENGTH_LONG, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                    }catch (IllegalArgumentException ignored){}

                }else{
                DefaultSharedPreferences.instance().storeValueBoolean(KEY_SHARED_PREFERENCES_USER_LOGGED, true);
                Toast toast = Toasty.success(getActivity(), Objects.requireNonNull(getActivity())
                        .getString(R.string.toast_cant_connect), Toast.LENGTH_LONG, true);
                toast.setGravity(Gravity.CENTER, 0,0);
                toast.show();
                ((MainActivity) Objects.requireNonNull(getActivity())).callLoginFragment();
                }
            }
        }

    private Bitmap loadImageLocal(String bitmapName){

        try{
            FileInputStream input = Objects.requireNonNull(getActivity()).openFileInput(bitmapName);
            return (BitmapFactory.decodeStream(input));

        }catch (Exception ignored) {}
        return null;
    }

    private void saveImageLocal(Bitmap newQRImage, String bitmapName){

        try{
            FileOutputStream output =
                    Objects.requireNonNull(getActivity()).openFileOutput(bitmapName, Context.MODE_PRIVATE);
            newQRImage.compress(Bitmap.CompressFormat.PNG, 100, output);
            output.close();
        }catch (Exception ignored) {}
    }
    private Bitmap createQRcode(String QRtext){

        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();

        try{

            BitMatrix bitMatrix = multiFormatWriter.encode(QRtext,
                    BarcodeFormat.QR_CODE, 250,250);
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            return barcodeEncoder.createBitmap(bitMatrix);
            }
        catch (WriterException ignored){}
        return null;
        }
    }
