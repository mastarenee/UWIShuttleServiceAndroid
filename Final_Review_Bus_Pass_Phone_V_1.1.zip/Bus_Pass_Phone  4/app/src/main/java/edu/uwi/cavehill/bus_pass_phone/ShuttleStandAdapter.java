package edu.uwi.cavehill.bus_pass_phone;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class ShuttleStandAdapter extends FirestoreRecyclerAdapter<ShuttleStand, ShuttleStandAdapter.ShuttleStandHolder>{

    //onClick listener for recycler view
    private OnItemClickListener mListener;

    public interface OnItemClickListener{

        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener){

        mListener = listener;
    }

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */

    public ShuttleStandAdapter(@NonNull FirestoreRecyclerOptions<ShuttleStand> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ShuttleStandHolder holder, int position, @NonNull ShuttleStand model) {

        holder.textViewName.setText(model.getNAME());
        holder.textViewDays.setText(model.getDAYS());
        holder.textViewTimes.setText(model.getTIMES());
        holder.textViewBreaks.setText(model.getBREAKS());
        holder.textViewNote.setText(model.getNOTE());

        holder.textViewLatitude.setText(String.valueOf((model.getDIRECTIONS().getLatitude())));
        holder.textViewLongitude.setText(String.valueOf((model.getDIRECTIONS().getLongitude())));

        }

    @NonNull
    @Override
    public ShuttleStandHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout
                .shuttle_stand_item, viewGroup, false);
        return new ShuttleStandHolder(view);
        }

    class ShuttleStandHolder extends RecyclerView.ViewHolder{

        TextView textViewName;
        TextView textViewDays;
        TextView textViewTimes;
        TextView textViewBreaks;
        TextView textViewNote;
        TextView textViewLatitude;
        TextView textViewLongitude;
        TextView textViewMore;

        public ShuttleStandHolder(View itemView) {

            super(itemView);
            textViewName= itemView.findViewById(R.id.text_view_name);
            textViewDays = itemView.findViewById(R.id.text_view_days);
            textViewTimes = itemView.findViewById(R.id.text_view_time);
            textViewBreaks = itemView.findViewById(R.id.text_view_breaks);
            textViewNote = itemView.findViewById(R.id.text_view_note);
            textViewLatitude = itemView.findViewById(R.id.text_view_lat);
            textViewLongitude = itemView.findViewById(R.id.text_view_long);

            //recycler view onClick
            textViewMore = itemView.findViewById(R.id.text_view_more);
            textViewMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null){
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            }
        }
    }
