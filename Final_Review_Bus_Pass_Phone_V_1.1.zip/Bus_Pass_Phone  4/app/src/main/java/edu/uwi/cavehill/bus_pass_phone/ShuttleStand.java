package edu.uwi.cavehill.bus_pass_phone;

import com.google.firebase.firestore.GeoPoint;

public class ShuttleStand {

    private String NAME, TIMES, DAYS, BREAKS, NOTE;
    private GeoPoint DIRECTIONS;

    public String getNAME() { return NAME; }

    public String getDAYS() { return DAYS; }

    public String getTIMES() { return TIMES; }

    public String getBREAKS() {return BREAKS;}

    public String getNOTE() {return NOTE;}

    public GeoPoint getDIRECTIONS(){return DIRECTIONS;}

    }
