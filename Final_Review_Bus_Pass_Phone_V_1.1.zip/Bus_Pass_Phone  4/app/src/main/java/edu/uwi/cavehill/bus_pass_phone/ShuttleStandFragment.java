package edu.uwi.cavehill.bus_pass_phone;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class ShuttleStandFragment extends Fragment {

    //Database Keys Users
    private static final String KEY_COLLECTION_FINAL_SHUTTLE_STANDS = "FINAL_SHUTTLE_STANDS";
    private static final String KEY_COLLECTION_CURRENT = "CURRENT";
    private static final String KEY_DOCUMENT_FR = "FR";
    private static final String KEY_DOCUMENT_ZH = "ZH";
    private static final String KEY_DOCUMENT_ES = "ES";
    private static final String KEY_DOCUMENT_PT = "PT";
    private static final String KEY_DOCUMENT_EN = "EN";
    private static final String KEY_FIELD_NAME = "NAME";

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_LANGUAGE = "languageKey";

    View view;

    private ShuttleStandAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.frament_shuttle_stand, container, false);

        // need try and catch for map intent in case user dont have a map installed
        setUpShuttleStand();

        return view;
        }

    private void setUpShuttleStand() {

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference SHUTTLERef;

        //fire store news language
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String language = sharedPreferences.getString(KEY_SHARED_PREFERENCES_LANGUAGE, "defaultValue");

        switch(language){

            case "fr":
                SHUTTLERef= db.collection(KEY_COLLECTION_FINAL_SHUTTLE_STANDS)
                        .document(KEY_DOCUMENT_FR).collection(KEY_COLLECTION_CURRENT);
                break;
            case "zh":
                SHUTTLERef= db.collection(KEY_COLLECTION_FINAL_SHUTTLE_STANDS)
                        .document(KEY_DOCUMENT_ZH).collection(KEY_COLLECTION_CURRENT);
                break;
            case "es":
                SHUTTLERef= db.collection(KEY_COLLECTION_FINAL_SHUTTLE_STANDS)
                        .document(KEY_DOCUMENT_ES).collection(KEY_COLLECTION_CURRENT);
                break;
            case "pt":
                SHUTTLERef= db.collection(KEY_COLLECTION_FINAL_SHUTTLE_STANDS)
                        .document(KEY_DOCUMENT_PT).collection(KEY_COLLECTION_CURRENT);
                break;
            default:
                SHUTTLERef= db.collection(KEY_COLLECTION_FINAL_SHUTTLE_STANDS)
                        .document(KEY_DOCUMENT_EN).collection(KEY_COLLECTION_CURRENT);

        }

        Toolbar shuttleStandToolbar = view.findViewById(R.id.shuttle_stand_toolbar);
        shuttleStandToolbar.setTitle(R.string.toolBar_shuttle_stand);

        //shows in alphabetical order for title.
        Query query = SHUTTLERef.orderBy(KEY_FIELD_NAME, Query.Direction.ASCENDING);

        final FirestoreRecyclerOptions<ShuttleStand> options = new FirestoreRecyclerOptions.Builder<ShuttleStand>()
                .setQuery(query, ShuttleStand.class)
                .build();
        adapter = new ShuttleStandAdapter(options);

        RecyclerView recyclerView = view.findViewById(R.id.shuttle_card_recycler_view);

        //for performance reasons(have no idea why)
        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerView.setAdapter(adapter);

        //recycler view onClick geolocation
        adapter.setOnItemClickListener(new ShuttleStandAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

                Double foundLatitude = options.getSnapshots().get(position).getDIRECTIONS().getLatitude();
                Double foundLongitude = options.getSnapshots().get(position).getDIRECTIONS().getLongitude();
                String foundName = options.getSnapshots().get(position).getNAME();

                // call external map intent
                callMapIntent(foundLatitude, foundLongitude, foundName);
            }
        });
    }

    private void callMapIntent(Double foundLatitude, Double foundLongitude, String name) {

        Uri gUri = Uri.parse("geo:0,0?q=" + foundLatitude +"," + foundLongitude + "(" + name + ")");
        Intent intent = new Intent(Intent.ACTION_VIEW, gUri);
        startActivity(intent);
    }

    //starts the database only when the app is in the foreground
    @Override
    public void onStart() {

        super.onStart();
        adapter.startListening();
    }

    //stops the database when the app is in the background
    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
