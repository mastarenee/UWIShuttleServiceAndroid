package edu.uwi.cavehill.bus_pass_phone;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;
import java.util.Random;

public class MyFirebaseInstanceService extends FirebaseMessagingService {

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_NOTIFICATION = "notificationKey";
    private static final String KEY_SHARED_PREFERENCES_VIBRATE = "vibrateKey";
    private static final String KEY_SHARED_PREFERENCES_DARK_MODE = "darkModeKey";

    private int notificationColor;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        notificationColor();

        boolean notification = (DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION));
        Log.d("nigelFire", Boolean.valueOf(notification).toString());

        if(notification){
            if(remoteMessage.getData().isEmpty())
                ShowNotification(remoteMessage.getNotification().getTitle(), remoteMessage.getNotification().getBody());

            else
                ShowNotification(remoteMessage.getData());
            }
        }

    private void ShowNotification(Map<String, String> data) {

        String title = data.get("title").toString();
        String body = data.get("body").toString();

        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "edu.uwi.cavehill.bus_pass_phone";
        boolean vibrate = (DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_VIBRATE ));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "Notification",
                    NotificationManager.IMPORTANCE_HIGH);

            notificationChannel.setDescription("YouWeShuttle Channel");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(vibrate);
            notificationManager.createNotificationChannel(notificationChannel);

        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);

        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(notificationColor)
                .setContentTitle(title)
                .setContentText(body)
                .setContentInfo("info");

        notificationManager.notify(new Random().nextInt(), notificationBuilder.build());

    }

    private void ShowNotification(String title, String body) {

        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "edu.uwi.cavehill.bus_pass_phone";
        boolean vibrate = (DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_VIBRATE));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "Notification",
                    NotificationManager.IMPORTANCE_HIGH);

            notificationChannel.setDescription("YouWeShuttle Channel");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(vibrate);
            notificationManager.createNotificationChannel(notificationChannel);

        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);

        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(notificationColor)
                .setContentTitle(title)
                .setContentText(body)
                .setContentInfo("info");

        notificationManager.notify(new Random().nextInt(), notificationBuilder.build());

    }

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
    }

    void notificationColor(){
        boolean darkMode = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_DARK_MODE);
        if (darkMode){
            notificationColor = ContextCompat.getColor(getApplicationContext(), R.color.darkColorNotificationIcon);
        } else {
            notificationColor = ContextCompat.getColor(getApplicationContext(), R.color.lightColorNotificationIcon);
        }
    }
}
