package edu.uwi.cavehill.bus_pass_phone;

import java.util.Date;

public class News {

    private String TITLE, DESCRIPTION;
    private Date DATE;

    public String getTitle() { return TITLE; }

    public String getDescription() {
        return DESCRIPTION;
    }

    public Date getDate() { return DATE; }

    }
