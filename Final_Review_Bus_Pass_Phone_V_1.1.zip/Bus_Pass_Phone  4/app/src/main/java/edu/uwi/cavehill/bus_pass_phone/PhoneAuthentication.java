package edu.uwi.cavehill.bus_pass_phone;

import android.app.KeyguardManager;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Toast;
import es.dmoral.toasty.Toasty;

public class PhoneAuthentication extends AppCompatActivity {

    private static final int LOCK_REQUEST_CODE = 221;
    private static final int SECURITY_SETTING_REQUEST_CODE = 233;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_authentication);

        authenticateAppPin();
    }

    //method to authenticate app
    private void authenticateAppPin() {
        //Get the instance of KeyGuardManager
        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);

        //Check if the device version is greater than or equal to Lollipop(21)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //Create an intent to open device screen lock screen to authenticate
            //Pass the Screen Lock screen Title and Description
            Intent i = keyguardManager.createConfirmDeviceCredentialIntent(getResources().getString(R.string.auth_unlock), getResources().getString(R.string.auth_confirm_pattern));

            try {
                //Start activity for result
                startActivityForResult(i, LOCK_REQUEST_CODE);
            } catch (Exception e) {

                //If some exception occurs means Screen lock is not set up please set screen lock
                //Open Security screen directly to enable patter lock
                Intent intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
                try {
                    Toast toast = Toasty.warning(this, this.getString(R.string.auth_create_password), Toast.LENGTH_LONG, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();

                    //Start activity for result
                    startActivityForResult(intent, SECURITY_SETTING_REQUEST_CODE);
                } catch (Exception ex) {

                    //If app is unable to find any Security settings then user has to set screen lock manually
                    Toast toast = Toasty.error(this, this.getString(R.string.auth_setting_label), Toast.LENGTH_SHORT, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case LOCK_REQUEST_CODE:
                if (resultCode == RESULT_OK) {
                    //If screen lock authentication is success update text
                    Toast toast = Toasty.success(this, this.getString(R.string.auth_unlock_success), Toast.LENGTH_SHORT, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    //If screen lock authentication is failed update text
                    Toast toast = Toasty.error(this, this.getString(R.string.auth_unlock_failed), Toast.LENGTH_SHORT, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                }
                break;
            case SECURITY_SETTING_REQUEST_CODE:
                //When user is enabled Security settings then we don't get any kind of RESULT_OK
                //So we need to check whether device has enabled screen lock or not
                if (isDeviceSecure()) {
                    //If screen lock enabled show toast and start intent to authenticate user
                    Toast toast = Toasty.info(this, this.getString(R.string.auth_password_created), Toast.LENGTH_SHORT, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                    authenticateAppPin();
                } else {
                    //If screen lock is not enabled just update text
                    Toast toast = Toasty.error(this, this.getString(R.string.auth_device_cancelled), Toast.LENGTH_SHORT, true);
                    toast.setGravity(Gravity.CENTER, 0,0);
                    toast.show();
                }
                break;
        }
    }
    // method to return whether device has screen lock enabled or not
    private boolean isDeviceSecure() {

        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return keyguardManager.isKeyguardSecure();
    }
}

