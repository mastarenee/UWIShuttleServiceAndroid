package edu.uwi.cavehill.bus_pass_phone;

import android.view.Gravity;
import android.widget.Toast;

import android.content.Context;

import es.dmoral.toasty.Toasty;

public class ToastSnack {


    public static void displayErrorToastLong(Context context, String msg){

        Toast toast = Toasty.error(context, msg, Toast.LENGTH_LONG, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displayErrorToastShort(Context context, String msg){

        Toast toast = Toasty.error(context, msg, Toast.LENGTH_SHORT, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displaySuccessToastLong(Context context, String msg){

        Toast toast = Toasty.success(context, msg, Toast.LENGTH_LONG, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displaySuccessToastShort(Context context, String msg){

        Toast toast = Toasty.success(context, msg, Toast.LENGTH_SHORT, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displayInfoToastLong(Context context, String msg){

        Toast toast = Toasty.info(context, msg, Toast.LENGTH_LONG, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displayInfoToastShort(Context context, String msg){

        Toast toast = Toasty.info(context, msg, Toast.LENGTH_SHORT, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displayWarningToastLong(Context context, String msg){

        Toast toast = Toasty.warning(context, msg, Toast.LENGTH_LONG, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    public static void displayWarningToastShort(Context context, String msg){

        Toast toast = Toasty.warning(context, msg, Toast.LENGTH_SHORT, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        toast.show();
        }

    }
