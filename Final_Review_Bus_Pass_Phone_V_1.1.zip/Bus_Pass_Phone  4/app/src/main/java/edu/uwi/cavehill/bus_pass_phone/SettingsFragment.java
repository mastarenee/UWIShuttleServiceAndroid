package edu.uwi.cavehill.bus_pass_phone;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import java.io.File;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import es.dmoral.toasty.Toasty;

public class SettingsFragment extends Fragment {

    View view;

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_NOTIFICATION = "notificationKey";
    private static final String KEY_SHARED_PREFERENCES_VIBRATE = "vibrateKey";
    private static final String KEY_SHARED_PREFERENCES_DARK_MODE = "darkModeKey";
    private static final String KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT = "settingsFragmentKey";
    private static final String KEY_SHARED_PREFERENCES_LANGUAGE = "languageKey";
    private static final String KEY_SHARED_PREFERENCES_LOCKED_SCREEN = "lockedScreenKey";
    private static final String KEY_SHARED_PREFERENCES_USER_LOGGED = "userLoggedKey";

    private int checkedItem;
    private FirebaseAuth mFirebaseAuth;
    private Button languageButton;
    private TextView website;


    private Button logoutButton;
    private Toolbar settingsToolbar;
    private RelativeLayout relativeLayout;

    private Switch switchNotification;
    private Switch switchVibrate;
    private Switch switchDark;
    private Switch switchLock;

    final private String websiteHTML = "https://www.cavehill.uwi.edu/studentservices/support-services/transportation.aspx";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.frament_settings, container, false);

        //set up the shuttle website link to download from the database

        setUpSettings();

        return view;
    }

    private void setUpSettings() {

        loadLocal();

        mFirebaseAuth = FirebaseAuth.getInstance();

        Toast toast = Toasty.error(getActivity(), Objects.requireNonNull(getActivity()).getString(R.string.toast_logged_out), Toast.LENGTH_SHORT, true);
        toast.setGravity(Gravity.CENTER, 0,0);
        //toast.show();

        languageButton = view.findViewById(R.id.language_button);

        settingsToolbar = view.findViewById(R.id.settings_toolbar);
        settingsToolbar.setTitle(R.string.toolBar_settings);
        logoutButton = view.findViewById(R.id.logout_button);

        relativeLayout = view.findViewById(R.id.settingsFragmentLayout);

        switchNotification = view.findViewById(R.id.switch_notifications);
        switchVibrate = view.findViewById(R.id.switch_vibrate);
        switchDark = view.findViewById(R.id.switch_dark);
        switchLock = view.findViewById(R.id.switch_lock);
        website = view.findViewById(R.id.website_html);


        //notifications
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        boolean notification = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION, false);
        boolean vibrate = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_VIBRATE, false);

        if(notification){
            switchNotification.setChecked(true);
        }

        if(vibrate){
            switchVibrate.setChecked(true);
        }

        switchNotification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if(isChecked){
                    switchVibrate.setEnabled(true);

                    editor.putBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION, true);
                    editor.apply();


                }else{
                    switchVibrate.setChecked(false);

                    editor.putBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION, false);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_VIBRATE, false);
                    editor.apply();

                }
            }
        });

        switchVibrate.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                boolean notification = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION, false);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if(isChecked && notification) {
                    switchVibrate.setChecked(true);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_VIBRATE, true);
                    editor.apply();

                }else { switchVibrate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                        boolean notification = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_NOTIFICATION, false);
                        if(!notification){
                            Toast toast = Toasty.warning(getActivity(), R.string.toast_enable_notification, Toast.LENGTH_SHORT, true);
                            toast.setGravity(Gravity.CENTER, 0,0);
                            toast.show();
                            switchVibrate.setChecked(false);
                        }
                    }
                });

                }

                }
        });

        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(websiteHTML));
                startActivity(browserIntent);
                }
         });

        //dark mode

        boolean darkMode = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_DARK_MODE, false);

        if(AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES || darkMode){
            switchDark.setChecked(true);
        }
        switchDark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                //load settings fragment on activity restart
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if(isChecked){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_DARK_MODE, true);
                    editor.apply();
                    restartSplashActivity();
                } else{
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.putBoolean(KEY_SHARED_PREFERENCES_DARK_MODE, false);
                    editor.apply();
                    restartSplashActivity();
                }
            }
        });

        //locked screen
        boolean lockedScreen = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_LOCKED_SCREEN, false);
        if(lockedScreen){
            switchLock.setChecked(true);
        }

        switchLock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if(isChecked){
                    editor.putBoolean(KEY_SHARED_PREFERENCES_LOCKED_SCREEN, true);
                    editor.apply();
                } else {
                    editor.putBoolean(KEY_SHARED_PREFERENCES_LOCKED_SCREEN, false);
                    editor.apply();
                }
            }
        });



        //shared preferences; edit and read

        boolean userLogged = sharedPreferences.getBoolean(KEY_SHARED_PREFERENCES_USER_LOGGED, false);

        if (userLogged){
            logoutButton.setVisibility(View.VISIBLE);

        }else {
            logoutButton.setVisibility(View.GONE);
        }

        logoutButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                logoutSnackBar();
            }
        });

        //language
        languageButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                showChangeLanguageDialog();
            }
        });

    }
    //language
    private void showChangeLanguageDialog() {

        checkedItem = 0;

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String language = sharedPreferences.getString(KEY_SHARED_PREFERENCES_LANGUAGE, "defaultValue");

        switch (language) {
            case "fr":
                checkedItem = 1;
                break;
            case "zh":
                checkedItem = 2;
                break;
            case "es":
                checkedItem = 3;
                break;
            case "pt":
                checkedItem = 4;
                break;
            default:
                checkedItem = 0;
        }

        final String[] languageItems = {"English", "Français", "中文", "Español", "Portugués"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getActivity().getString(R.string.alert_choose_settings));
        builder.setSingleChoiceItems(languageItems, checkedItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                //load settings fragment on activity restart
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = sharedPreferences.edit();

                if (which == checkedItem){
                    dialog.dismiss();
                }
                else if (which == 0) {

                    setLocale("en");
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.apply();
                    restartSplashActivity();
                }
                else if (which == 1) {

                    setLocale("fr");
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.apply();
                    restartSplashActivity();
                }
                else if (which == 2) {

                    setLocale("zh");
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.apply();
                    restartSplashActivity();
                }
                else if (which == 3) {

                    setLocale("es");
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.apply();
                    restartSplashActivity();
                }
                else if (which == 4) {

                    setLocale("pt");
                    editor.putBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, true);
                    editor.apply();
                    restartSplashActivity();
                }

                dialog.dismiss();
            }

        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void setLocale(String language) {

        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        getActivity().getBaseContext().getResources().updateConfiguration(configuration,
                getActivity().getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_SHARED_PREFERENCES_LANGUAGE, language);
        editor.apply();

    }

    public void loadLocal(){

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String language = sharedPreferences.getString(KEY_SHARED_PREFERENCES_LANGUAGE, "defaultValue");
        setLocale(language);
    }

    //linear layout can do this indefinite as it is able to swipe snack bar off screen
    private void logoutSnackBar() {

        Snackbar snackbar = Snackbar.make(relativeLayout,
                getActivity().getString(R.string.snack_sure), Snackbar.LENGTH_LONG)
                .setAction(getActivity().getString(R.string.snack_yes), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        performLogout();
                    }
                })
                .setActionTextColor(Color.RED);

        View snackView = snackbar.getView();
        snackView.setBackgroundColor(Color.BLACK);
        TextView textView = snackView.findViewById(android.support.design.R.id.snackbar_text);
        textView.setTextColor(Color.YELLOW);


        snackbar.show();
    }

    private void performLogout() {

        clearSharedPreference();
        clearFiles();
        mFirebaseAuth.signOut();
        logoutButton.setVisibility(View.GONE);
        restartSplashActivity();
    }

    //used for debuging to clear shared preferences
    private void clearSharedPreference() {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
    }

    private void clearFiles() {
        File[] files = Objects.requireNonNull(getContext()).getFilesDir().listFiles();
        if(files != null)
            for(File file : files) {
                file.deleteOnExit();
                }
            }

    //once logged out restart the main activity
    private void restartSplashActivity() {

        Intent intent = new Intent(getActivity(), SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        getActivity().overridePendingTransition(0, 0);
        getActivity().finish();
        getActivity().overridePendingTransition(0, 0);
        startActivity(intent);
        }
    }