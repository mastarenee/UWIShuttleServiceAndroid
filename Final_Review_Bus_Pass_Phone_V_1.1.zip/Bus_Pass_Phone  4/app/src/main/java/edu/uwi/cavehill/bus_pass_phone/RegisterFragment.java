package edu.uwi.cavehill.bus_pass_phone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterFragment extends Fragment {

    View view;

    private ProgressBar registerProgressbar;
    private EditText registerEmail;
    private EditText registerPassword;
    private EditText registerConfirmPassword;

    private FirebaseAuth mFirebaseAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.frament_register, container, false);

        setUpRegistration();

        return view;
    }

    private void setUpRegistration() {

        Toolbar registerToolbar = view.findViewById(R.id.register_toolbar);
        registerToolbar.setTitle(R.string.toolBar_register);
        registerProgressbar = view.findViewById(R.id.register_progressBar);
        registerEmail = view.findViewById(R.id.register_email_editText);
        registerPassword = view.findViewById(R.id.register_password_editText);
        registerConfirmPassword = view.findViewById(R.id.register_confirm_password_editText);
        Button registerButton = view.findViewById(R.id.register_button);
        final TextView register = view.findViewById(R.id.register_register);
        TextView help = view.findViewById(R.id.register_help);
        final ImageView registerImage = view.findViewById(R.id.register_image_register);

        mFirebaseAuth = FirebaseAuth.getInstance();

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //verify email and password
                if (!VerifyEmailPassword.isFieldEmpty(registerEmail.getText().toString(),
                        registerPassword.getText().toString(),
                        registerConfirmPassword.getText().toString())) {
                    Toast.makeText(getActivity(), R.string.toast_empty_fields, Toast.LENGTH_SHORT).show();

                    } else if(VerifyEmailPassword.isValidEmailAddress(registerEmail.getText().toString())) {
                    Toast.makeText(getActivity(), R.string.toast_valid_email, Toast.LENGTH_SHORT).show();
                    registerPassword.setText("");
                    registerConfirmPassword.setText("");

                    } else if(VerifyEmailPassword.isValidUWIEmail(registerEmail.getText().toString())) {
                    Toast.makeText(getActivity(), R.string.toast_valid_UWImail, Toast.LENGTH_SHORT).show();
                    registerPassword.setText("");
                    registerConfirmPassword.setText("");

                    } else if(VerifyEmailPassword.isValidPassword(registerPassword.getText().toString())) {
                    Toast.makeText(getActivity(), R.string.toast_valid_password, Toast.LENGTH_SHORT).show();
                    registerPassword.setText("");
                    registerConfirmPassword.setText("");

                    } else if(!VerifyEmailPassword.isValidConfirmPassword(registerPassword.getText().toString(), registerConfirmPassword.getText().toString())) {
                    callConfirmPasswordsDialog();

                } else  {

                    //start progressbar
                    registerImage.setVisibility(View.INVISIBLE);
                    registerProgressbar.setVisibility(View.VISIBLE);

                    //use OnCompletListener to verify registration was successful
                    mFirebaseAuth.createUserWithEmailAndPassword(registerEmail.getText().toString(),
                            registerPassword.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {

                                //send user a verification email
                                mFirebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if (task.isSuccessful()){

                                            registerEmail.setText("");
                                            registerPassword.setText("");
                                            registerConfirmPassword.setText("");

                                            //stop progressbar
                                            registerProgressbar.setVisibility(View.INVISIBLE);

                                            //this toast need to put somewhere else cause it does not show when the fragment switches
                                            Toast.makeText(getActivity(), R.string.toast_success_check_mail, Toast.LENGTH_LONG).show();

                                            //logout firestore
                                            mFirebaseAuth.signOut();

                                            //call another fragment
                                            LoginFragment loginFragment = new LoginFragment();
                                            FragmentManager manager = getFragmentManager();
                                            manager.beginTransaction()
                                                    .replace(R.id.fragment_container, loginFragment)
                                                    .commit();
                                        } else {

                                            registerPassword.setText("");
                                            registerConfirmPassword.setText("");
                                            Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });

                                } else{

                                //had to do this in case null was received. can't get rid of warning though
                                if (task.getException().getMessage() == null) {

                                    registerEmail.setText("");
                                    registerPassword.setText("");
                                    registerConfirmPassword.setText("");

                                    //stop progressbar
                                    registerProgressbar.setVisibility(View.INVISIBLE);

                                    Toast.makeText(getActivity(), R.string.toast_unsuccess_try_again, Toast.LENGTH_SHORT).show();

                                    //logout firestore
                                    mFirebaseAuth.signOut();
                                    } else{

                                    registerPassword.setText("");
                                    registerConfirmPassword.setText("");

                                    //stop progressbar
                                    registerProgressbar.setVisibility(View.INVISIBLE);
                                    registerImage.setVisibility(View.VISIBLE);

                                    Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                                    //logout firestore
                                    mFirebaseAuth.signOut();
                                    }
                                }
                            }
                            });
                    }
                }
        });

        register.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                //call another LoginFragment fragment
                LoginFragment loginFragment = new LoginFragment();
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction()
                        .replace(R.id.fragment_container, loginFragment).commit();

            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callHelpDialog();
            }
        });
    }

    private void callHelpDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());

        dialog.setTitle(R.string.alert_help_title_register)
                .setMessage(R.string.alert_help_message_register)
                .setPositiveButton(R.string.alert_help_ok_register, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {dialog.dismiss();}
                    });
        dialog.create();
        dialog.show();
        }

    private void callConfirmPasswordsDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
        dialog.setTitle(R.string.alert_mismatch_title_register)
                .setMessage(R.string.alert_mismatch_message_register)
                .setPositiveButton(R.string.alert_mismatch_ok_register, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {dialog.dismiss();}
                    });
        dialog.create();
        dialog.show();
        }
    }
