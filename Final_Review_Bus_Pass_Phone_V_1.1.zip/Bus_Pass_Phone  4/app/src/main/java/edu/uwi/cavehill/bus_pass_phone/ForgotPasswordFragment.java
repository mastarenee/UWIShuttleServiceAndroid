package edu.uwi.cavehill.bus_pass_phone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import java.util.Objects;

public class ForgotPasswordFragment extends Fragment {

    View view;

    private FirebaseAuth mFirebaseAuth;
    private ProgressBar resetProgressbar;
    private EditText forgotPasswordEmail;
    private TextView help;
    private ImageView resetImage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.frament_forgot_password, container, false);

        setUpPasswordReset();

        return view;
        }

    private void setUpPasswordReset() {

        Toolbar reset_password_toolbar = view.findViewById(R.id.reset_password_toolbar);
        reset_password_toolbar.setTitle(R.string.toolBar_forgot_password);
        resetProgressbar = view.findViewById(R.id.reset_progressBar);
        forgotPasswordEmail = view.findViewById(R.id.reset_email_editText);
        Button resetButton = view.findViewById(R.id.reset_email_button);
        TextView resetLogin = view.findViewById(R.id.reset_return_login);
        help = view.findViewById(R.id.reset_help);
        resetImage = view.findViewById(R.id.reset_image_reset);

        mFirebaseAuth = FirebaseAuth.getInstance();

        resetButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (!VerifyEmailPassword.isFieldEmpty(forgotPasswordEmail.getText().toString())) {

                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_empty_fields));

                    } else if(VerifyEmailPassword.isValidEmailAddress(forgotPasswordEmail.getText().toString())) {

                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_valid_email));

                    } else if(VerifyEmailPassword.isValidUWIEmail(forgotPasswordEmail.getText().toString())) {

                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_valid_UWImail));

                    } else {beginPasswordReset();}
                }
            });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callHelpDialog();
            }
        });

        resetLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                ((MainActivity) Objects.requireNonNull(getActivity())).callLoginFragment();
                }
            });
        }

    private void beginPasswordReset() {

        resetImage.setVisibility(View.INVISIBLE);
        resetProgressbar.setVisibility(View.VISIBLE);
        mFirebaseAuth.sendPasswordResetEmail(forgotPasswordEmail.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<Void>() {

            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()){

                    resetProgressbar.setVisibility(View.INVISIBLE);
                    ToastSnack.displayInfoToastLong(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_forgot_password));
                    mFirebaseAuth.signOut();
                    forgotPasswordEmail.setText("");
                    ((MainActivity) Objects.requireNonNull(getActivity())).callLoginFragment();

                } else {

                    resetProgressbar.setVisibility(View.INVISIBLE);
                    resetImage.setVisibility(View.VISIBLE);
                    ToastSnack.displayInfoToastLong(getActivity(), Objects.requireNonNull(task.getException())
                            .getMessage());
                    }
                }
            });

        }

    private void callHelpDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());

        dialog.setTitle(R.string.alert_help_title_register)
                .setMessage(R.string.alert_help_message_register)
                .setPositiveButton(R.string.alert_help_ok_register, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {}
                 });

        dialog.create();
        dialog.show();

        }
    }
