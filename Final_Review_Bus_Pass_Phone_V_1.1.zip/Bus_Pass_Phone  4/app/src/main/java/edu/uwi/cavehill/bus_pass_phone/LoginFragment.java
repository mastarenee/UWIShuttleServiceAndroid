package edu.uwi.cavehill.bus_pass_phone;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;


public class LoginFragment extends Fragment {

    View view;

    private FirebaseAuth mFirebaseAuth;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ProgressBar loginProgressbar;
    private EditText loginEmail;
    private EditText loginPassword;

    //Database Keys Users
    private static final String KEY_COLLECTION_FINAL_USERS = "FINAL_USERS";
    private static final String KEY_DOCUMENT_PASSENGERS = "PASSENGERS";
    private static final String KEY_FIELD_NAME = "NAME";

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_QR_CODE = "textQRCodeKey";
    private static final String KEY_SHARED_PREFERENCES_USER_NAME = "userNameKey";
    private static final String KEY_SHARED_PREFERENCES_USER_LOGGED = "userLoggedKey";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Objects.requireNonNull(getActivity()).getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        view = inflater.inflate(R.layout.frament_login, container, false);

        setUpLogin();

        return view;

        }

    private void setUpLogin() {

        Toolbar loginToolbar = view.findViewById(R.id.login_toolbar);
        loginToolbar.setTitle(R.string.toolBar_login);
        loginProgressbar = view.findViewById(R.id.login_progressBar);
        loginEmail = view.findViewById(R.id.login_email_editText);
        loginPassword = view.findViewById(R.id.login_password_editText);
        Button loginButton = view.findViewById(R.id.login_button);
        TextView notRegistered = view.findViewById(R.id.login_not_registered);
        TextView forgotPassword = view.findViewById(R.id.login_forgot_password);
        TextView help = view.findViewById(R.id.login_help);
        final ImageView loginImage = view.findViewById(R.id.login_image_login);

        mFirebaseAuth = FirebaseAuth.getInstance();

        loginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (!VerifyEmailPassword.isFieldEmpty(loginEmail.getText().toString(),
                        loginPassword.getText().toString())) {

                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_empty_fields));

                    }else if(VerifyEmailPassword.isValidEmailAddress(loginEmail.getText().toString())) {

                    loginPassword.setText("");
                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_valid_email));

                    }else if(VerifyEmailPassword.isValidUWIEmail(loginEmail.getText().toString())) {

                    loginPassword.setText("");
                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_valid_UWImail));

                    }else if(VerifyEmailPassword.isValidPassword(loginPassword.getText().toString())) {
                    loginPassword.setText("");
                    ToastSnack.displayErrorToastShort(getActivity(), Objects.requireNonNull(getActivity())
                            .getString(R.string.toast_valid_password));

                    }else {
                    loginImage.setVisibility(View.INVISIBLE);
                    loginProgressbar.setVisibility(View.VISIBLE);

                    //use OnCompletListener to verify login is successful before moving on to the next task
                    mFirebaseAuth.signInWithEmailAndPassword(loginEmail.getText().toString(), loginPassword.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    //use isSuccessful to verify task is successful
                                    if (task.isSuccessful()) {

                                        //verifies email has been verified
                                        if (mFirebaseAuth.getCurrentUser().isEmailVerified()){
                                            final String userEmail = mFirebaseAuth.getCurrentUser().getEmail();

                                            DocumentReference USERSRef = db.collection(KEY_COLLECTION_FINAL_USERS )
                                                    .document(KEY_DOCUMENT_PASSENGERS);

                                            //use OnCompletListener to verify QR code text get from database is successful
                                            USERSRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                                                    if(task.isSuccessful()){

                                                        DocumentSnapshot documentSnapshot = task.getResult();

                                                        if(documentSnapshot != null){

                                                            HashMap<String, String> map = (HashMap<String, String>) documentSnapshot.getData().get(userEmail);
                                                            final String userName = map.get(KEY_FIELD_NAME);

                                                            if (userEmail == null || userName == null){
                                                                ToastSnack.displayErrorToastLong(getActivity(), getString(R.string.toast_cant_connect));
                                                                mFirebaseAuth.signOut();
                                                                ((MainActivity) Objects.requireNonNull(getActivity())).callShuttleCardFragment();

                                                            } else {
                                                                DefaultSharedPreferences.instance().storeValueString(KEY_SHARED_PREFERENCES_QR_CODE, userEmail);
                                                                DefaultSharedPreferences.instance().storeValueString(KEY_SHARED_PREFERENCES_USER_NAME, userName);
                                                                DefaultSharedPreferences.instance().storeValueBoolean(KEY_SHARED_PREFERENCES_USER_LOGGED, true);

                                                                loginProgressbar.setVisibility(View.INVISIBLE);
                                                                mFirebaseAuth.signOut();

                                                                ((MainActivity) Objects.requireNonNull(getActivity())).callShuttleCardFragment();
                                                            }

                                                            }else {

                                                            ToastSnack.displayErrorToastLong(getActivity(), Objects.requireNonNull(getActivity())
                                                                    .getString(R.string.toast_user_blank));
                                                            }
                                                     }
                                                    }
                                                });
                                            }else {

                                            loginEmail.setText("");
                                            loginPassword.setText("");
                                            loginProgressbar.setVisibility(View.INVISIBLE);

                                            ToastSnack.displayWarningToastLong(getActivity(), Objects.requireNonNull(getActivity())
                                                    .getString(R.string.toast_verify_email));
                                            mFirebaseAuth.signOut();
                                            }

                                    } else {

                                        loginEmail.setText("");
                                        loginPassword.setText("");
                                        loginProgressbar.setVisibility(View.INVISIBLE);
                                        loginImage.setVisibility(View.VISIBLE);

                                        ToastSnack.displayWarningToastLong(getActivity(), Objects.requireNonNull(task.getException())
                                                .getMessage());
                                        mFirebaseAuth.signOut();

                                        }
                                    }
                                });
                    }
            }
            });

        notRegistered.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                ((MainActivity) Objects.requireNonNull(getActivity())).callRegisterFragment();
                }
            });

        forgotPassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

        ((MainActivity) Objects.requireNonNull(getActivity())).callForgotPasswordFragment();
                }
            });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callHelpDialog();
                }
            });
        }

    private void callHelpDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());

        dialog.setTitle(R.string.alert_help_title_register)
        .setMessage(R.string.alert_help_message_register)
                .setPositiveButton(R.string.alert_help_ok_register, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {}
                });

        dialog.create();
        dialog.show();

        }

    }
