package edu.uwi.cavehill.bus_pass_phone;

import java.util.regex.Pattern;

public class VerifyEmailPassword {

    public static boolean isValidEmailAddress(String email) {

        String emailRegex = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\." +
                "[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern emailPattern = java.util.regex.Pattern.compile(emailRegex);
        java.util.regex.Matcher emailMatcher = emailPattern.matcher(email);
        return !emailMatcher.matches();
        }

    public static boolean isValidUWIEmail(String email) {

        String emailDomain = email.substring(email.lastIndexOf("@") + 1).toLowerCase();
        return !emailDomain.equals("mycavehill.uwi.edu") && !emailDomain.equals("cavehill.uwi.edu");
        }

    public static boolean isValidPassword(String password) {

        String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,16}$";
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        return !passwordPattern.matcher(password).matches();
        }

    public static boolean isFieldEmpty(String email, String password) {

        return !email.isEmpty() && !password.isEmpty();
        }

    public static boolean isFieldEmpty(String email, String password, String confirmPassword) {

        return !email.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty();
        }

    public static boolean isFieldEmpty(String email) {

        return !email.isEmpty();
        }

    public static boolean isValidConfirmPassword(String password, String confirmPassword) {

        return password.equals(confirmPassword);
        }

    }
