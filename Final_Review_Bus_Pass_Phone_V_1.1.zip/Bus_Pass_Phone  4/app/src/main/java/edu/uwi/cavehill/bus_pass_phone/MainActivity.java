package edu.uwi.cavehill.bus_pass_phone;

import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity {

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT = "settingsFragmentKey";
    private static final String KEY_SHARED_PREFERENCES_DARK_MODE = "darkModeKey";
    private static final String KEY_SHARED_PREFERENCES_USER_LOGGED = "userLoggedKey";

    // null crashes program so used this instead. The home page is called in Main
    //this is just a holder to prevent a crash.
    Fragment selectedFragment = null;
    boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //load bottom navigation
        BottomNavigationView bottomNavigation;
        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(navListener);


        //needed for shared preferences class
        edu.uwi.cavehill.bus_pass_phone.DefaultSharedPreferences.instance(this.getApplicationContext());

        //shared preferences; verifies which fragment to load news or settings and dark mode on app start

        boolean loadSettingsFragment = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT);
        boolean darkMode = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_DARK_MODE);

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES || darkMode){
            setTheme(R.style.DarkTheme);

            //change the status bar
            Window window = this.getWindow();

            // clear FLAG_TRANSLUCENT_STATUS flag:
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

            // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

            // finally change the color
            window.setStatusBarColor(ContextCompat.getColor(this,R.color.darkColorPrimary));

            //cant seem to get the dark theme to go to the nav bar so i had to do this
            bottomNavigation.setBackgroundColor(this.getResources().getColor(R.color.darkColorPrimary,
                    this.getTheme()));

        }else {
            setTheme(R.style.AppTheme);
        }

        if (loadSettingsFragment){

            //load settings fragment
            DefaultSharedPreferences.instance().storeValueBoolean(KEY_SHARED_PREFERENCES_SETTINGS_FRAGMENT, false);

            findViewById(R.id.nav_settings).performClick();
            callSettingsFragment();

            }else {
                //load home fragment which is news
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new NewsFragment()).commit();
            }
        }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                //to save on memory fragments are destroyed once switched and new ones are always created.
                switch (item.getItemId()){
                    case R.id.nav_news:
                        selectedFragment = new NewsFragment();
                        break;

                    case R.id.nav_shuttle_card:

                        //shared preferences; verifies user logged in then shows appropriate fragment
                        boolean userLogged = DefaultSharedPreferences.instance().fetchValueBoolean(KEY_SHARED_PREFERENCES_USER_LOGGED);

                        if (userLogged){
                            selectedFragment = new ShuttleCardFragment();

                            }else {
                            selectedFragment = new LoginFragment();
                            }
                        break;

                    case R.id.nav_shuttle_stand:
                        selectedFragment = new ShuttleStandFragment();
                        break;

                    case R.id.nav_settings:
                        selectedFragment = new SettingsFragment();
                        break;
                    }

                    //call selected fragment
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    selectedFragment).commit();

            return true;
                }
        };

    public void callForgotPasswordFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new ForgotPasswordFragment()).commit();
        }
    public void callRegisterFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new RegisterFragment()).commit();
        }
    public void callShuttleCardFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new ShuttleCardFragment()).commit();
        }

    public void callLoginFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new LoginFragment()).commit();
        }

    public void callSettingsFragment() {

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                new SettingsFragment()).commit();
        }
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        ToastSnack.displayInfoToastShort(this, this.getString(R.string.toast_back_twice));

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }


}
