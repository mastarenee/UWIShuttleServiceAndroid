package edu.uwi.cavehill.bus_pass_phone;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class NewsFragment extends Fragment {

    View view;

    //Database Keys Users
    private static final String KEY_COLLECTION_FINAL_NEWS = "FINAL_NEWS";
    private static final String KEY_COLLECTION_CURRENT = "CURRENT";
    private static final String KEY_DOCUMENT_FR = "FR";
    private static final String KEY_DOCUMENT_ZH = "ZH";
    private static final String KEY_DOCUMENT_ES = "ES";
    private static final String KEY_DOCUMENT_PT = "PT";
    private static final String KEY_DOCUMENT_EN = "EN";
    private static final String KEY_FIELD_DATE = "DATE";

    //Shared Preferences Keys
    private static final String KEY_SHARED_PREFERENCES_LANGUAGE = "languageKey";

    private Toolbar newsToolbar;
    private NewsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.frament_news, container, false);

        setUpRecyclerView();

        return view;
    }

    private void setUpRecyclerView() {

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference NEWSRef;

        //fire store news language
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        String language = sharedPreferences.getString(KEY_SHARED_PREFERENCES_LANGUAGE, "defaultValue");
        switch(language){

            case "fr":
                NEWSRef= db.collection(KEY_COLLECTION_FINAL_NEWS).document(KEY_DOCUMENT_FR)
                        .collection(KEY_COLLECTION_CURRENT);
                break;
            case "zh":
                NEWSRef= db.collection(KEY_COLLECTION_FINAL_NEWS).document(KEY_DOCUMENT_ZH)
                        .collection(KEY_COLLECTION_CURRENT);
                break;
            case "es":
                NEWSRef= db.collection(KEY_COLLECTION_FINAL_NEWS).document(KEY_DOCUMENT_ES)
                        .collection(KEY_COLLECTION_CURRENT);
                break;
            case "pt":
                NEWSRef= db.collection(KEY_COLLECTION_FINAL_NEWS).document(KEY_DOCUMENT_PT)
                        .collection(KEY_COLLECTION_CURRENT);
                break;
            default:
                NEWSRef= db.collection(KEY_COLLECTION_FINAL_NEWS).document(KEY_DOCUMENT_EN)
                        .collection(KEY_COLLECTION_CURRENT);
        }

        newsToolbar = view.findViewById(R.id.toolbar_news);
        newsToolbar.setTitle(R.string.toolBar_news);

        //shows in order of date; the latest date is always first
        Query query = NEWSRef.orderBy(KEY_FIELD_DATE, Query.Direction.DESCENDING);

        FirestoreRecyclerOptions<News> options = new FirestoreRecyclerOptions.Builder<News>()
                .setQuery(query, News.class)
                .build();
        adapter = new NewsAdapter(options);

        RecyclerView recyclerView = view.findViewById(R.id.news_recycler_view);

        //for performance reasons(have no idea why)
        recyclerView.setHasFixedSize(true);

        recyclerView.setLayoutManager(new LinearLayoutManager(this.getActivity()));
        recyclerView.setAdapter(adapter);
    }

    //starts the database only when the app is in the foreground
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    //stops the database when the app is in the background
    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
