package edu.uwi.cavehill.bus_pass_phone;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class DefaultSharedPreferences {

    static DefaultSharedPreferences _instance;

    Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor sharedPreferencesEditor;

    public static DefaultSharedPreferences instance(Context context) {
        if (_instance == null) {
            _instance = new DefaultSharedPreferences();
            _instance.configSessionUtils(context);
        }
        return _instance;
    }

    public static DefaultSharedPreferences instance() {
        return _instance;
    }

    public void configSessionUtils(Context context) {
        this.context = context;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        sharedPreferencesEditor = sharedPreferences.edit();
    }

    public void storeValueString(String key, String value) {
        sharedPreferencesEditor.putString(key, value);
        sharedPreferencesEditor.apply();
    }

    public String fetchValueString(String key) {
        return sharedPreferences.getString(key, "defaultValue");
    }

    public void storeValueBoolean(String key, boolean value) {
        sharedPreferencesEditor.putBoolean(key, value);
        sharedPreferencesEditor.apply();
    }

    public boolean fetchValueBoolean(String key) { return sharedPreferences.getBoolean(key, false); }
}
