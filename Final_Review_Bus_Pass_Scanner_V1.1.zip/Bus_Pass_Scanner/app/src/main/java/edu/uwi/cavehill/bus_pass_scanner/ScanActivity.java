package edu.uwi.cavehill.bus_pass_scanner;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class ScanActivity extends AppCompatActivity{

    private SoundPool soundPool;
    private int valid, invalid;
    private String modifiedQrCode;

    //Bundle keys
    private static final String KEY_BUNDLE_RESULT = "result";

    //Passenger email domain
    private static final String KEY_DOMAIN_PASSENGER_EMAIL = "cavehill.uwi.edu";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        modifiedQrCode = "blank@blank.com";

        setUpSound();
        setUpQrCodeScan();
        }

    //start scanning for qr code
    private void setUpQrCodeScan(){

        IntentIntegrator intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        //can't set below value in string's
        intentIntegrator.setPrompt("Scanning For QR Code In Progress");
        intentIntegrator.setCameraId(0);
        intentIntegrator.setOrientationLocked(true);
        intentIntegrator.setBeepEnabled(false);
        intentIntegrator.setBarcodeImageEnabled(true);
        intentIntegrator.initiateScan();
        }

    //result from camera scanner
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (intentResult != null){

            if (intentResult.getContents() == null){

                callIdentityActivity();
                Toast.makeText(this, R.string.scan_cancelled_this_scan
                        , Toast.LENGTH_LONG).show();
                }else{

                if (validateCode(intentResult.getContents())){

                    soundPool.play(valid, 1, 1, 0, 0, 1);
                    modifiedQrCode = intentResult.getContents();
                    Toast.makeText(this, R.string.scan_valid_qr, Toast.LENGTH_LONG).show();
                    callIdentityActivity();
                    }else{

                    soundPool.play(invalid, 1, 1, 0, 0, 1);
                    Toast.makeText(this, R.string.scan_invalid_qr, Toast.LENGTH_LONG).show();
                    setUpQrCodeScan();
                    }
                }
            }else{ super.onActivityResult(requestCode, resultCode, data); }
        }

    //validate QR code scanned is of ours
    private boolean validateCode(String code){

        String lastCodeChars = code.substring(code.length() - 16);
        return lastCodeChars.equals(KEY_DOMAIN_PASSENGER_EMAIL);
        }

    //set up sound
    public void setUpSound(){

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(audioAttributes)
                .build();

        valid = soundPool.load(this, R.raw.valid, 1);
        invalid = soundPool.load(this, R.raw.invalid, 1);
        }

    @Override
    protected void onDestroy(){

        super.onDestroy();
        soundPool.release();
        soundPool = null;
        }

    public void callIdentityActivity() {

        Intent openIdentityActivity = new Intent(this, IdentityActivity.class);
        openIdentityActivity.putExtra(KEY_BUNDLE_RESULT, modifiedQrCode);
        openIdentityActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        setResult(RESULT_OK, openIdentityActivity);
        startActivityIfNeeded(openIdentityActivity, 100);
        finish();
        }

    @Override
    public void onBackPressed(){}

    }
