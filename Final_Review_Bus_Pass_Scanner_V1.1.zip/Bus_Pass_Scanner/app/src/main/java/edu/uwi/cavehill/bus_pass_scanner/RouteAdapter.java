package edu.uwi.cavehill.bus_pass_scanner;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class RouteAdapter extends FirestoreRecyclerAdapter<Route, RouteAdapter.RouteHolder>{

    //onClick listener for recycler view
    private OnItemClickListener mListener;

    public interface OnItemClickListener{

        void onItemClick(int position);
        }

    void setOnItemClickListener(OnItemClickListener listener){

        mListener = listener;
        }

    RouteAdapter(@NonNull FirestoreRecyclerOptions<Route> options) {

        super(options);
        }

    @Override
    protected void onBindViewHolder(@NonNull RouteHolder holder, int position, @NonNull Route model) {

        holder.textViewTitle.setText(model.getName());
        holder.textViewDescription.setText(model.getDescription());
        }

    @NonNull
    @Override
    public RouteHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout
                .route_item, viewGroup, false);

        return new RouteHolder(view);
        }

    class RouteHolder extends RecyclerView.ViewHolder{

        TextView textViewTitle, textViewDescription;
        RouteHolder(View itemView){

            super(itemView);

            //recycler view onClick
            textViewTitle = itemView.findViewById(R.id.text_view_name);
            textViewDescription = itemView.findViewById(R.id.text_view_description);
            textViewTitle.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v){

                    if (mListener != null){

                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION){

                            mListener.onItemClick(position);
                            }
                        }
                    }
                });
            }
        }
    }
