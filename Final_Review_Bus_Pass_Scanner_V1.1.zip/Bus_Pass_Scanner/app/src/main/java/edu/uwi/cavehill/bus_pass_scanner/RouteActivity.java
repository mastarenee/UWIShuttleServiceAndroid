package edu.uwi.cavehill.bus_pass_scanner;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import javax.annotation.Nullable;

public class RouteActivity extends AppCompatActivity{

    private RouteAdapter adapter;
    private RecyclerView mRecyclerView;
    public ProgressBar mProgressBar;
    private TextView routeLoading;
    private String driverEmail;

    //Database Keys
    private static final String  KEY_COLLECTION_SHUTTLE_STANDS = "FINAL_SHUTTLE_STANDS";
    private static final String  KEY_COLLECTION_SHUTTLE_STANDS_EN = "EN";
    private static final String  KEY_COLLECTION_SHUTTLE_STANDS_CURRENT = "CURRENT";
    private static final String  KEY_FIELD_NAME = "NAME";

    //Bundle keys
    private static final String KEY_BUNDLE_DRIVER_NAME = "driverName";
    private static final String KEY_BUNDLE_ROUTE_NAME = "routeName";
    private static final String KEY_BUNDLE_NEW_QRCODE = "newQrCode";

    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.toolbar_route);

        mProgressBar = findViewById(R.id.route_progressBar);
        mRecyclerView = findViewById(R.id.route_recycler_view);
        routeLoading = findViewById(R.id.route_loading);

        driverEmail = "defaultValue";
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) { driverEmail = bundle.getString(KEY_BUNDLE_DRIVER_NAME); }

        routeLoading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingCancelDialog();
            }
        });

        setUpRoute();
        }

    private void loadingCancelDialog() {

            android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);
            dialog.setTitle(R.string.alert_loading_title_login)
                    .setMessage(R.string.alert_loading_message_login)
                    .setPositiveButton(R.string.alert_loading_ok_login, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int id){
                            callLoginActivity();
                        }
                    }).setNegativeButton(R.string.alert_loading_cancel_login, new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialog, int which){
                    dialog.dismiss();
                }
            });
            dialog.create();
            dialog.show();

    }

    private void setUpRoute(){

        showProgressBar();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference ROUTERef = db.collection(KEY_COLLECTION_SHUTTLE_STANDS)
                .document(KEY_COLLECTION_SHUTTLE_STANDS_EN).collection(KEY_COLLECTION_SHUTTLE_STANDS_CURRENT);

        Query query = ROUTERef.orderBy(KEY_FIELD_NAME, Query.Direction.ASCENDING);

        final FirestoreRecyclerOptions<Route> options = new FirestoreRecyclerOptions.Builder<Route>()
                .setQuery(query, Route.class)
                .build();
        adapter = new RouteAdapter(options);

        RecyclerView recyclerView = findViewById(R.id.route_recycler_view);

        //for performance reasons(have no idea why)
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        ROUTERef.addSnapshotListener(new EventListener<QuerySnapshot>(){
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e){

                if (queryDocumentSnapshots != null && !queryDocumentSnapshots.isEmpty()){
                    hideProgressBar();
                    }
                }
            });

        //recycler view onClick route name

        adapter.setOnItemClickListener(new RouteAdapter.OnItemClickListener(){
            @Override
            public void onItemClick(int position){

                String routeName = options.getSnapshots().get(position).getName();
                verifyRouteDialog(routeName);
                }
            });
        }

    private void verifyRouteDialog(String routeName){

        final String newRouteName = routeName;
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_route_verify_title)
                .setMessage(routeName)

                .setPositiveButton(R.string.alert_route_ok, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        callIdentityActivity(newRouteName);
                        }
                    })

                .setNegativeButton(R.string.alert_route_cancel, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        dialog.dismiss();
                        }
                    });

        dialog.create();
        dialog.show();
        }

    private void callIdentityActivity(String routeName){

        Intent intent = new Intent(this, IdentityActivity.class);
        intent.putExtra(KEY_BUNDLE_DRIVER_NAME, driverEmail);
        intent.putExtra(KEY_BUNDLE_ROUTE_NAME, routeName);
        intent.putExtra(KEY_BUNDLE_NEW_QRCODE,"blank@blank.com");
        startActivity(intent);
        }

    private void callLoginActivity(){

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void showProgressBar(){
        mRecyclerView.setVisibility(View.GONE);
        mProgressBar.setVisibility(View.VISIBLE);
        routeLoading.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar(){
        mProgressBar.setVisibility(View.GONE);
        routeLoading.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.VISIBLE);
    }

    //starts the database only when the app is in the foreground
    @Override
    public void onStart(){
        super.onStart();
        adapter.startListening();
        }

    //stops the database when the app is in the background
    @Override
    public void onStop(){
        super.onStop();
        adapter.stopListening();
        }

    @Override
    public void onBackPressed(){}

    }
