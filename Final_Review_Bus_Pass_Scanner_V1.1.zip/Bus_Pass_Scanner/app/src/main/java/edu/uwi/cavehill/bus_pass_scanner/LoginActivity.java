package edu.uwi.cavehill.bus_pass_scanner;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mFirebaseAuth;
    private FirebaseFirestore db;
    private Toolbar toolbar;

    private ScrollView mScrollView;
    private ProgressBar mProgressBar;

    private ImageView loginImage;
    private ImageView resetImage;

    private TextView loginLoading;
    private TextView loginResetPassword;
    private TextView loginLogin;
    private TextInputLayout loginPasswordToggle;

    private EditText loginEmail;
    private EditText loginPassword;
    private EditText loginEmailReset;

    private Button loginButton;
    private Button resetPasswordButton;

    private String driverEmail;
    private String driverName;

    //Database Keys
    private static final String  KEY_COLLECTION_USERS = "FINAL_USERS";
    private static final String  KEY_DOCUMENT_DRIVERS = "DRIVERS";
    private static final String  KEY_FIELD_NAME = "NAME";

    //Driver email domain
    private static final String KEY_DOMAIN_DRIVER_EMAIL = "hotmail.com";

    //Bundle keys
    private static final String KEY_BUNDLE_DRIVER_NAME = "driverName";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextView loginHelp = findViewById(R.id.login_help);

        mFirebaseAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        mScrollView = findViewById(R.id.scroll_view);
        mProgressBar = findViewById(R.id.login_progressBar);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.toolbar_login);

        loginImage = findViewById(R.id.login_image_login);
        resetImage = findViewById(R.id.login_image_reset);

        loginLoading = findViewById(R.id.login_loading);
        loginResetPassword = findViewById(R.id.login_reset);
        loginLogin = findViewById(R.id.login_login);
        loginPasswordToggle = findViewById(R.id.login_password_text_input);

        loginEmail = findViewById(R.id.login_email_editText);
        loginPassword = findViewById(R.id.login_password_editText);
        loginEmailReset = findViewById(R.id.login_reset_editText);

        loginButton = findViewById(R.id.login_button);
        resetPasswordButton = findViewById(R.id.login_reset_button);

        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                if(!isFieldEmpty(loginEmail.getText().toString(), loginPassword.getText().toString())){

                    if(isValidEmailAddress(loginEmail.getText().toString())){

                        if(isValidUWIEmail(loginEmail.getText().toString())){

                            if(isValidPassword(loginPassword.getText().toString())){
                                setUpLogin();
                                }else{
                                Toast.makeText(LoginActivity.this, R.string.login_valid_password, Toast.LENGTH_LONG).show();
                                }
                            }else{
                            Toast.makeText(LoginActivity.this, R.string.login_valid_driver_email, Toast.LENGTH_LONG).show();
                            }
                        }else{
                        Toast.makeText(LoginActivity.this, R.string.login_valid_email, Toast.LENGTH_LONG).show();
                        }
                    }else{
                    Toast.makeText(LoginActivity.this, R.string.login_fill_fields, Toast.LENGTH_LONG).show();
                    }
                }
            });

        resetPasswordButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(!isFieldEmpty(loginEmailReset.getText().toString())){

                    if(isValidEmailAddress(loginEmailReset.getText().toString())){

                        if(isValidUWIEmail(loginEmailReset.getText().toString())){
                            setUpResetPassword();
                            }else{
                            Toast.makeText(LoginActivity.this, R.string.login_valid_driver_email, Toast.LENGTH_LONG).show();
                            }
                        }else{
                        Toast.makeText(LoginActivity.this, R.string.login_valid_email, Toast.LENGTH_LONG).show();
                        }
                    }else{
                    Toast.makeText(LoginActivity.this, R.string.login_fill_fields, Toast.LENGTH_LONG).show();
                }
                }
            });

        loginLoading.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { loadingCancelDialog(); }
            });

        loginHelp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ callHelpDialog(); }
            });

        loginResetPassword.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { showResetPasswordPage(); }
            });

        loginLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { showLoginPage(); }
            });
        }

    private void loadingCancelDialog(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_loading_title_login)
                .setMessage(R.string.alert_loading_message_login)
                .setPositiveButton(R.string.alert_loading_ok_login, new DialogInterface.OnClickListener(){
                    public void onClick(final DialogInterface dialog, int id){
                        loginEmail.setText("");
                        loginPassword.setText("");
                        showLoginPage();
                        hideProgressBar();
                    }
                }).setNegativeButton(R.string.alert_loading_cancel_login, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        dialog.create();
        dialog.show();
    }

    private void setUpResetPassword(){

        showProgressBar();

        driverEmail = loginEmailReset.getText().toString();
        DocumentReference DRIVERSRef = db.collection(KEY_COLLECTION_USERS).document(KEY_DOCUMENT_DRIVERS);

        DRIVERSRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>(){
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task){

                if(task.isSuccessful()){

                    final DocumentSnapshot documentSnapshot = task.getResult();
                    if(documentSnapshot.exists()){

                        if(documentSnapshot.getData().containsKey(driverEmail)){
                            mFirebaseAuth.sendPasswordResetEmail(loginEmailReset.getText().toString())
                                    .addOnCompleteListener(new OnCompleteListener<Void>(){

                                        @Override
                                        public void onComplete(@NonNull Task<Void> task){

                                            LoginActivity.super.recreate();
                                            hideProgressBar();
                                            Toast.makeText(LoginActivity.this, R.string.login_reset_email_sent, Toast.LENGTH_LONG).show();
                                            }
                                        });
                            }else{

                            loginEmailReset.setText("");
                            LoginActivity.super.recreate();
                            hideProgressBar();
                            Toast.makeText(LoginActivity.this, R.string.login_not_driver, Toast.LENGTH_LONG).show();
                            }
                        }else{

                        Toast.makeText(LoginActivity.this, R.string.login_network_fail, Toast.LENGTH_LONG).show();
                        LoginActivity.super.recreate();
                        }
                    }else{

                    Toast.makeText(LoginActivity.this, R.string.login_network_fail, Toast.LENGTH_LONG).show();
                    LoginActivity.super.recreate();
                    }
                }
            });
        }

    private void setUpLogin(){

        showProgressBar();
        mFirebaseAuth.signInWithEmailAndPassword(loginEmail.getText().toString(), loginPassword.getText().toString())
                .addOnSuccessListener(new OnSuccessListener<AuthResult>(){
                    @Override
                    public void onSuccess(AuthResult authResult){

                        if(mFirebaseAuth.getCurrentUser() != null && mFirebaseAuth.getCurrentUser().isEmailVerified()){

                            driverEmail = mFirebaseAuth.getCurrentUser().getEmail();
                            DocumentReference DRIVERSRef = db.collection(KEY_COLLECTION_USERS).document(KEY_DOCUMENT_DRIVERS);

                            DRIVERSRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>(){
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task){

                                    if(task.isSuccessful()){

                                        DocumentSnapshot documentSnapshot = task.getResult();

                                        if(documentSnapshot.exists()){

                                            if(documentSnapshot.getData().containsKey(driverEmail)){
                                                HashMap<String, String> map = (HashMap<String, String>) documentSnapshot.getData().get(driverEmail);
                                                driverName = map.get(KEY_FIELD_NAME);
                                                callRouteActivity();

                                            }else{
                                                Toast.makeText(LoginActivity.this, R.string.login_not_driver, Toast.LENGTH_LONG).show();
                                                loginEmail.setText("");
                                                loginPassword.setText("");
                                                LoginActivity.super.recreate();
                                            }
                                        }else{
                                            Toast.makeText(LoginActivity.this, R.string.login_network_fail, Toast.LENGTH_LONG).show();
                                            LoginActivity.super.recreate();
                                        }
                                    }else{
                                        Toast.makeText(LoginActivity.this, R.string.login_network_fail, Toast.LENGTH_LONG).show();
                                        LoginActivity.super.recreate();
                                    }
                                }
                            });
                        }else{

                            LoginActivity.super.recreate();
                            hideProgressBar();
                            Toast.makeText(LoginActivity.this, R.string.login_verify_email_first, Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener(){
                    @Override
                    public void onFailure(@NonNull Exception e){

                        LoginActivity.super.recreate();
                        hideProgressBar();
                        Toast.makeText(LoginActivity.this, String.valueOf(e.getMessage()), Toast.LENGTH_LONG).show();
                    }
                });
        }

    private void callHelpDialog(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_help_title_register)
                .setMessage(R.string.alert_help_message_register)
                .setPositiveButton(R.string.alert_help_ok_register, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int id) {dialog.dismiss();}
                });
        dialog.create();
        dialog.show();
        }

    private void showLoginPage(){

        loginImage.setVisibility(View.VISIBLE);
        loginButton.setVisibility(View.VISIBLE);
        loginPassword.setVisibility(View.VISIBLE);
        loginEmail.setVisibility(View.VISIBLE);
        loginPassword.setVisibility(View.VISIBLE);
        loginPasswordToggle.setVisibility(View.VISIBLE);
        loginResetPassword.setVisibility(View.VISIBLE);

        resetImage.setVisibility(View.INVISIBLE);
        resetPasswordButton.setVisibility(View.INVISIBLE);
        loginEmailReset.setVisibility(View.INVISIBLE);
        loginEmailReset.setText("");
        loginLogin.setVisibility(View.INVISIBLE);
        toolbar.setTitle(R.string.toolbar_login);
        }

    private void showResetPasswordPage(){

        loginImage.setVisibility(View.INVISIBLE);
        loginButton.setVisibility(View.INVISIBLE);
        loginPassword.setVisibility(View.INVISIBLE);
        loginEmail.setVisibility(View.INVISIBLE);
        loginEmail.setText("");
        loginPassword.setText("");
        loginPassword.setVisibility(View.INVISIBLE);
        loginResetPassword.setVisibility(View.INVISIBLE);
        loginPasswordToggle.setVisibility(View.INVISIBLE);
        loginResetPassword.setVisibility(View.INVISIBLE);

        resetImage.setVisibility(View.VISIBLE);
        resetPasswordButton.setVisibility(View.VISIBLE);
        loginEmailReset.setVisibility(View.VISIBLE);
        loginLogin.setVisibility(View.VISIBLE);
        toolbar.setTitle(R.string.toolbar_forgot_password);
        }

    private void showProgressBar(){

        mScrollView.setVisibility(View.INVISIBLE);
        mProgressBar.setVisibility(View.VISIBLE);
        loginLoading.setVisibility(View.VISIBLE);
        }

    private void hideProgressBar(){

        mScrollView.setVisibility(View.VISIBLE);
        mProgressBar.setVisibility(View.INVISIBLE);
        loginLoading.setVisibility(View.INVISIBLE);
        }

    private static boolean isValidEmailAddress(String email){

        String emailRegex = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\." +
                "[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
        java.util.regex.Pattern emailPattern = java.util.regex.Pattern.compile(emailRegex);
        java.util.regex.Matcher emailMatcher = emailPattern.matcher(email);
        return emailMatcher.matches();
        }

    public static boolean isValidUWIEmail(String email){

        String emailDomain = email.substring(email.lastIndexOf("@") + 1).toLowerCase();
        return emailDomain.equals(KEY_DOMAIN_DRIVER_EMAIL);
        }

    public static boolean isValidPassword(String password){

        String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,16}$";
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        return passwordPattern.matcher(password).matches();
        }

    private static boolean isFieldEmpty(String email, String password) { return email.isEmpty() && password.isEmpty(); }

    private static boolean isFieldEmpty(String email) { return email.isEmpty(); }

    public void callRouteActivity(){
        Intent intent = new Intent(this, RouteActivity.class);
        intent.putExtra(KEY_BUNDLE_DRIVER_NAME, driverName);
        startActivity(intent);
        finish();
        }

    AlertDialog _alert;
    @Override
    public void onPause(){
        super.onPause();
        if(_alert != null) _alert.dismiss();
        }

    @Override
    public void onBackPressed(){}
    }
