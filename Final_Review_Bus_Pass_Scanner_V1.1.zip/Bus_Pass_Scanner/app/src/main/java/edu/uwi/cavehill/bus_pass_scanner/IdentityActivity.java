package edu.uwi.cavehill.bus_pass_scanner;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IdentityActivity extends AppCompatActivity {

    private Handler mHandler = new Handler();
    private FirebaseAuth mFirebaseAuth = FirebaseAuth.getInstance();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    private String userEmail;
    private String driverEmail;
    private String routeName;
    private String scanDate;
    private Timestamp scanTime;
    private boolean scanStarted;
    private boolean logsSystemOnline;
    private int usersOnBoard;

    CollectionReference PASSENGERRef;
    DocumentReference tripLogsRef;

    ProgressBar mProgressBar;
    ProgressBar oProgressbar;
    RelativeLayout pictureRelativeLayout;
    RelativeLayout buttonRelativeLayout;
    CardView pictureCardView;

    //Database Keys Passengers
    private static final String KEY_COLLECTION_FINAL_USERS = "FINAL_USERS";
    private static final String KEY_DOCUMENT_PASSENGERS = "PASSENGERS";
    private static final String KEY_FIELD_DATABASE_AVAILABLE = "DATABASE_AVAILABLE";
    private static final String KEY_FIELD_NAME = "NAME";
    private static final String KEY_FIELD_SEX = "SEX";
    private static final String KEY_FIELD_ID = "UID";
    private static final String KEY_FIELD_LEVEL = "LEVEL";
    private static final String KEY_FIELD_ARREARS = "ARREARS";
    private static final String KEY_FIELD_IMAGE_URL = "IMAGE_URL";

    //Database Keys Logs
    private static final String KEY_COLLECTION_TRIP_LOGS = "FINAL_TRIP_LOGS";
    private static final String KEY_FIELD_TIMESTAMP_TRIP_LOGS = "TIMESTAMP";
    private static final String KEY_FIELD_PASSENGERS_COUNT_TRIP_LOGS = "PASSENGERS_COUNT";
    private static final String KEY_FIELD_DRIVER_EMAIL_TRIP_LOGS = "DRIVER_EMAIL";
    private static final String KEY_FIELD_PASSENGERS_TRIP_LOGS = "PASSENGERS";
    private static final String KEY_FIELD_PASSENGERS_LEFT_TRIP_LOGS = "PASSENGERS_LEFT";

    //Bundle keys
    private static final String KEY_BUNDLE_DRIVER_NAME = "driverName";
    private static final String KEY_BUNDLE_ROUTE_NAME = "routeName";
    private static final String KEY_BUNDLE_NEW_QR_CODE = "newQrCode";
    private static final String KEY_BUNDLE_RESULT = "result";

    private TextView identityName;
    private TextView identitySex;
    private TextView identityId;
    private TextView identityLevel;
    private TextView identityLoading;
    private TextView identitySystemOnline;
    private TextView identitySoulsOnBoard;
    private TextView identityDriverEmail;
    private TextView identityRouteName;
    private ImageView identityImage;
    private Button identitySyncDatabase;
    private Button identityStartScanning;
    private Button identityStopScanning;
    private Button identityAllowButton;
    private Button identityDenyButton;

    boolean accessColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identity);

        scanStarted = false;
        logsSystemOnline = false;
        accessColor = false;

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.toolbar_identity);
        userEmail = "blank@blank.com";
        driverEmail = "defaultValue";
        routeName = "defaultValue";

        usersOnBoard = -1;

        identityDriverEmail = findViewById(R.id.identity_driver_email);
        identityRouteName = findViewById(R.id.identity_route_name);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            userEmail = bundle.getString(KEY_BUNDLE_NEW_QR_CODE);
            driverEmail = bundle.getString(KEY_BUNDLE_DRIVER_NAME);
            routeName = bundle.getString(KEY_BUNDLE_ROUTE_NAME);
            identityRouteName.setText(routeName);
            identityDriverEmail.setText(driverEmail);
            
            identityDriverEmail.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){ callLogoutDialog(); }});

            identityRouteName.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View v){ callRouteChangeDialog(); }});
        }

        tripLogsRef = db.collection(KEY_COLLECTION_TRIP_LOGS).document(routeName);
        PASSENGERRef = db.collection(KEY_COLLECTION_FINAL_USERS);

        mProgressBar = findViewById(R.id.identity_progressBar);
        oProgressbar = findViewById(R.id.identity_system_online_progress);
        identityName = findViewById(R.id.identity_name);
        identitySex = findViewById(R.id.identity_sex);
        identityId = findViewById(R.id.identity_id);
        identityLevel = findViewById(R.id.identity_level);
        identityLoading = findViewById(R.id.identity_loading);
        identityImage = findViewById(R.id.identity_image);
        identitySystemOnline = findViewById(R.id.identity_system_online);
        identitySoulsOnBoard = findViewById(R.id.identity_users_onboard_count);
        identitySyncDatabase = findViewById(R.id.identity_sync_database);
        identityStartScanning = findViewById(R.id.identity_start_scan);
        identityStopScanning = findViewById(R.id.identity_stop_scan);
        pictureRelativeLayout = findViewById(R.id.identity_image_relative);
        buttonRelativeLayout = findViewById(R.id.identity_button_relative);
        pictureCardView = findViewById(R.id.identity_image_card);
        identityAllowButton = findViewById(R.id.identity_allow_button);
        identityDenyButton = findViewById(R.id.identity_deny_button);

        identitySyncDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                syncDatabaseDialog();
            }
        });

        identityAllowButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                callScanActivity();
                identityAllowButton.setVisibility(View.GONE);
                identityDenyButton.setVisibility(View.GONE);
                updateDatabase();
                }
            });

        identityDenyButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                callScanActivity();
                identityAllowButton.setVisibility(View.GONE);
                identityDenyButton.setVisibility(View.GONE);
            }
        });
        }

    private void setUpDriverPanel(){

        identityDriverEmail.setText(driverEmail);
        identityRouteName.setText(routeName);
        oProgressbar.setVisibility(View.VISIBLE);
        identitySystemOnline.setVisibility(View.INVISIBLE);
        pictureRelativeLayout.setVisibility(View.VISIBLE);

        setUpOnline();

        identityLoading.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                if(scanStarted){ callLoadingDialog(); }
                }
            });

        identityStopScanning.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) { stopScanDialog(); }
        });

        loadIdentity();

    }

    private void setUpOnline(){

        DocumentReference documentReference = PASSENGERRef.document(KEY_DOCUMENT_PASSENGERS);
        documentReference.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>(){

                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot){

                        if(documentSnapshot.exists()){

                            if(documentSnapshot.getBoolean(KEY_FIELD_DATABASE_AVAILABLE) != null){
                                oProgressbar.setVisibility(View.INVISIBLE);
                                identitySystemOnline.setBackgroundColor(Color.parseColor("#27AE60"));
                                identitySystemOnline.setText(getString(R.string.identity_system_online));
                                identitySystemOnline.setVisibility(View.VISIBLE);
                                showButtonColors("green");

                                identityStartScanning.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v){

                                        if(logsSystemOnline){
                                            startScanDialog();
                                            }
                                        }
                                    });

                            }else{
                                showButtonColors("red");
                                Toast.makeText(IdentityActivity.this, R.string.identity_default_user_negative, Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        pictureRelativeLayout.setBackgroundColor(Color.parseColor("#C0392b"));
                        identitySystemOnline.setBackgroundColor(Color.parseColor("#C0392b"));
                        identitySystemOnline.setText(getString(R.string.identity_system_offline));
                        identitySystemOnline.setVisibility(View.VISIBLE);
                        oProgressbar.setVisibility(View.INVISIBLE);
                        showButtonColors("red");

                        identitySystemOnline.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                setDatabaseShell();
                                setUpDriverPanel();
                            }
                        });
                    }
                });
    }

    private void loadIdentity() {

        DocumentReference documentReference = PASSENGERRef
                .document(KEY_DOCUMENT_PASSENGERS);

        startProgressBar();

        documentReference.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {

                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {

                        if (documentSnapshot.exists()){
                            HashMap<String, String> map = (HashMap<String, String>) documentSnapshot.getData().get(userEmail);
                            String name = (map.get(KEY_FIELD_NAME));
                            String sex = (map.get(KEY_FIELD_SEX));
                            String id = (map.get(KEY_FIELD_ID));
                            String level = (map.get(KEY_FIELD_LEVEL));
                            String imageUrl = (map.get(KEY_FIELD_IMAGE_URL));
                            String tempAccessColor = String.valueOf((map.get(KEY_FIELD_ARREARS)));
                            accessColor = Boolean.valueOf(tempAccessColor);

                            identityName.setText(name);
                            identitySex.setText(sex);
                            identityId.setText(id);
                            identityLevel.setText(level);

                            Glide.with(IdentityActivity.this).load(imageUrl).listener(new RequestListener<Drawable>() {

                                @Override
                                public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) { return false; }

                                @Override
                                public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                                    stopProgressBar();
                                    showAccessColors();

                                    if(scanStarted && accessColor){
                                        mHandler.removeCallbacks(mRunnable);

                                        if(!accessColor){
                                            mHandler.postDelayed(mRunnable, 4000);
                                            updateDatabase();
                                            }
                                        }

                                    return false;

                                    }
                                })
                                    .into(identityImage);

                            }else{

                            showButtonColors("red");
                            Toast.makeText(IdentityActivity.this, R.string.identity_network_negative, Toast.LENGTH_LONG).show();
                            stopProgressBar();

                            }
                        }
                    })

                .addOnFailureListener(new OnFailureListener() {

                    @Override
                    public void onFailure(@NonNull Exception e) {

                        showButtonColors("red");
                        Toast.makeText(IdentityActivity.this,R.string.identity_network_negative , Toast.LENGTH_LONG).show();
                        stopProgressBar();

                        }
                    });
        }

    private void startProgressBar(){

        mProgressBar.setVisibility(View.VISIBLE);
        identityLoading.setVisibility(View.VISIBLE);
        identityName.setVisibility(View.INVISIBLE);
        identitySex.setVisibility(View.INVISIBLE);
        identityId.setVisibility(View.INVISIBLE);
        identityLevel.setVisibility(View.INVISIBLE);
        identityImage.setVisibility(View.INVISIBLE);
        pictureRelativeLayout.setVisibility(View.INVISIBLE);
        pictureCardView.setVisibility(View.INVISIBLE);
        }

    private void stopProgressBar(){

        mProgressBar.setVisibility(View.INVISIBLE);
        identityLoading.setVisibility(View.INVISIBLE);
        identityName.setVisibility(View.VISIBLE);
        identitySex.setVisibility(View.VISIBLE);
        identityId.setVisibility(View.VISIBLE);
        identityLevel.setVisibility(View.VISIBLE);
        identityImage.setVisibility(View.VISIBLE);
        pictureRelativeLayout.setVisibility(View.VISIBLE);
        pictureCardView.setVisibility(View.VISIBLE);
        }

    private void showAccessColors(){

        if (accessColor){

            pictureRelativeLayout.setBackgroundColor(Color.parseColor("#C0392b"));
            identityAllowButton.setVisibility(View.VISIBLE);
            identityDenyButton.setVisibility(View.VISIBLE);
            mHandler.removeCallbacks(mRunnable);

            }else{
            pictureRelativeLayout.setBackgroundColor(Color.parseColor("#27AE60"));

            if(scanStarted){
                mHandler.postDelayed(mRunnable, 4000);
                }
            updateDatabase();
            }
        }

    private void showButtonColors(String color){

        //Used a string instead of boolean as eventually have to add new colors
        if(color.equals("green")){

            buttonRelativeLayout.setBackgroundColor(Color.parseColor("#27AE60"));
        }else{

            buttonRelativeLayout.setBackgroundColor(Color.parseColor("#C0392b"));
            }
        }

    private void resetSoulsCount(){
        usersOnBoard = 0;
        identitySoulsOnBoard.setText(String.valueOf(usersOnBoard));
    }

    private void callLeftBehindDialog(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_left_behind);
        dialog.setMessage(R.string.alert_identity_message_left_behind);

        final EditText input = new EditText(this);

        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        KeyListener keyListener = DigitsKeyListener.getInstance("1234567890");
        input.setKeyListener(keyListener);

        dialog.setView(input);

        dialog.setPositiveButton(R.string.alert_identity_ok_left_behind, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){

                identityAllowButton.setVisibility(View.GONE);
                identityDenyButton.setVisibility(View.GONE);
                final String identityPassengersLeft = input.getText().toString();

                tripLogsRef.get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>(){

                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot){

                                if(documentSnapshot.exists()){
                                    String mapLeftCount = scanDate + "." + KEY_FIELD_PASSENGERS_LEFT_TRIP_LOGS;
                                    tripLogsRef.update(mapLeftCount, identityPassengersLeft);
                                }
                            }
                        });
                }
            });
        dialog.setNegativeButton(R.string.alert_identity_cancel_left_behind, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.cancel();
                }
            });
        dialog.show();
        }

    private void callLogoutDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_logout)
                .setMessage(R.string.alert_identity_message_logout)
                .setPositiveButton(R.string.alert_identity_ok_logout, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mHandler.removeCallbacks(mRunnable);
                        mFirebaseAuth.signOut();
                        callLoginActivity();
                    }
                })
                .setNegativeButton(R.string.alert_identity_cancel_logout, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.create();
        dialog.show();
        }

    private void callLoadingDialog(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_loading)
                .setMessage(R.string.alert_identity_message_loading)
                .setPositiveButton(R.string.alert_identity_ok_loading, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){

                        mHandler.removeCallbacks(mRunnable);
                        callScanActivity();
                    }
                })
                .setNegativeButton(R.string.alert_identity_cancel_loading, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.create();
        dialog.show();
        }

    private void callRouteChangeDialog() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_route_change)
                .setMessage(R.string.alert_identity_message_route_change)
                .setPositiveButton(R.string.alert_identity_ok_route_change, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        callRouteActivity();
                    }
                })
                .setNegativeButton(R.string.alert_identity_cancel_route_change, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        dialog.create();
        dialog.show();
        }

    private void callLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void callRouteActivity() {

        Intent openRouteActivity = new Intent(this, RouteActivity.class);
        openRouteActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivityIfNeeded(openRouteActivity, 0);
        finish();
    }

    private void callScanActivity() {
        Intent intent = new Intent(this, ScanActivity.class);
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 100){
            if(resultCode == RESULT_OK){
                if (data != null){

                    String tempUserEmail = data.getStringExtra(KEY_BUNDLE_RESULT);
                    if(!(tempUserEmail.equals("blank@blank.com"))){
                        userEmail = tempUserEmail;
                        }else{
                        mHandler.postDelayed(mRunnable, 4000);
                        }
                    }
                }

            if(resultCode == RESULT_CANCELED){

                mHandler.postDelayed(mRunnable, 4000);
                showButtonColors("red");
                }
            }
        }

    private void unClickableStartScan(){
        identityDriverEmail.setClickable(false);
        identityRouteName.setClickable(false);
        identitySystemOnline.setClickable(false);
    }

    private void clickableStopScan(){
        identityDriverEmail.setClickable(true);
        identityRouteName.setClickable(true);
        identitySystemOnline.setClickable(true);
    }

    @Override
    public void onResume(){
        super.onResume();
        loadIdentity();
        }

    private void syncDatabaseDialog(){

        android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_sync_database)
                .setMessage(R.string.alert_identity_message_sync_database)
                .setPositiveButton(R.string.alert_identity_ok_sync_database, new DialogInterface.OnClickListener(){
                    public void onClick(final DialogInterface dialog, int id){

                        scanStarted = false;
                        setDatabaseShell();
                        setUpDriverPanel();
                        identityStartScanning.setVisibility(View.VISIBLE);
                        identitySyncDatabase.setVisibility(View.GONE);
                    }
                }).setNegativeButton(R.string.alert_identity_cancel_sync_database, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        dialog.create();
        dialog.show();
    }

    private void startScanDialog(){

        android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_start_scan)
                .setMessage(R.string.alert_identity_message_start_scan)
                .setPositiveButton(R.string.alert_identity_ok_start_scan, new DialogInterface.OnClickListener(){
                    public void onClick(final DialogInterface dialog, int id){

                        scanStarted = true;
                        unClickableStartScan();
                        callScanActivity();
                        showButtonColors("red");
                        identityStartScanning.setVisibility(View.INVISIBLE);
                        identityStopScanning.setVisibility(View.VISIBLE);
                    }
                }).setNegativeButton(R.string.alert_identity_cancel_start_scan, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                dialog.dismiss();
            }
        });
        dialog.create();
        dialog.show();
    }

    private void stopScanDialog(){

        mHandler.removeCallbacks(mRunnable);
        android.app.AlertDialog.Builder dialog = new android.app.AlertDialog.Builder(this);
        dialog.setTitle(R.string.alert_identity_title_stop_scan)
                .setMessage(R.string.alert_identity_message_stop_scan)
                .setPositiveButton(R.string.alert_identity_ok_stop_scan, new DialogInterface.OnClickListener(){
                    public void onClick(final DialogInterface dialog, int id){
                        callLeftBehindDialog();
                        scanStarted = false;
                        stopProgressBar();
                        identityAllowButton.setVisibility(View.GONE);
                        identityDenyButton.setVisibility(View.GONE);
                        clickableStopScan();
                        showButtonColors("green");
                        identityStartScanning.setVisibility(View.VISIBLE);
                        identityStopScanning.setVisibility(View.INVISIBLE);
                        resetSoulsCount();
                    }
                }).setNegativeButton(R.string.alert_identity_cancel_stop_scan, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                callScanActivity();
                dialog.dismiss();
            }
        });
        dialog.create();
        dialog.show();
    }

    private void setDatabaseShell(){

        scanDate = String.valueOf(new Date());
        scanTime = new Timestamp(new Date());

        Map<String, Object> nestedData = new HashMap<>();
        Map<String, Object> docData = new HashMap<>();
        nestedData.put(KEY_FIELD_TIMESTAMP_TRIP_LOGS, scanTime);
        nestedData.put(KEY_FIELD_PASSENGERS_COUNT_TRIP_LOGS, 0);
        nestedData.put(KEY_FIELD_PASSENGERS_LEFT_TRIP_LOGS, 0);
        nestedData.put(KEY_FIELD_DRIVER_EMAIL_TRIP_LOGS, driverEmail);
        nestedData.put(KEY_FIELD_PASSENGERS_TRIP_LOGS, Collections.emptyList());
        docData.put(scanDate, nestedData);

        tripLogsRef
                .set(docData, SetOptions.merge())
                .addOnCompleteListener(new OnCompleteListener<Void>(){
                    @Override
                    public void onComplete(@NonNull Task<Void> task){
                        if(task.isSuccessful()){

                            logsSystemOnline = true;
                            accessColor = false;
                            showAccessColors();
                            soulsOnBoardCount();

                            }else{
                            accessColor = true;
                            showAccessColors();
                            }
                        }
                    });
        }

    private void updateDatabase(){

        if(!(userEmail.equals("blank@blank.com"))){
            String mapNamePassengers = scanDate + "." + KEY_FIELD_PASSENGERS_TRIP_LOGS;
            tripLogsRef
                    .update(mapNamePassengers, FieldValue.arrayUnion(userEmail))
                    .addOnCompleteListener(new OnCompleteListener<Void>(){

                        @Override
                        public void onComplete(@NonNull Task<Void> task){

                            if(task.isSuccessful()){
                                soulsOnBoardCount(); }
                            }
                        });
            }
        }

    private void soulsOnBoardCount(){

        tripLogsRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>(){

                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot){

                        if(documentSnapshot.exists()){
                            HashMap<String, List> map = (HashMap<String, List>) documentSnapshot.getData().get(scanDate);
                            usersOnBoard = (map.get(KEY_FIELD_PASSENGERS_TRIP_LOGS)).size();
                            identitySoulsOnBoard.setText(String.valueOf(usersOnBoard));
                            String mapNameCount = scanDate + "." + KEY_FIELD_PASSENGERS_COUNT_TRIP_LOGS;
                            tripLogsRef.update(mapNameCount, usersOnBoard);
                        }
                    }
                });
        }

    private Runnable mRunnable = new Runnable(){

        @Override
        public void run(){

                callScanActivity();
                mHandler.postDelayed(this, 4000);
                mHandler.removeCallbacks(mRunnable);
            }
        };

    AlertDialog _alert;
    @Override
    public void onPause(){
        super.onPause();
        if(_alert != null) _alert.dismiss();
    }

    @Override
    public void onBackPressed(){}

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(mHandler != null && mRunnable != null)
            mHandler.removeCallbacks(mRunnable);
        }
    }
