package edu.uwi.cavehill.bus_pass_scanner;

public class Route{

    private String NAME, DESCRIPTION;

    public String getName() { return NAME; }

    public String getDescription() { return DESCRIPTION; }

    }
